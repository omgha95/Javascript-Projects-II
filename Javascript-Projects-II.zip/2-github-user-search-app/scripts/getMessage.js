import { messageElement } from "./elements";

export default function () {
  return messageElement.innerText;
}
